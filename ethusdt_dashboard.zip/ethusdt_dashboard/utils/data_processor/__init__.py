"""
Data processor package initialization
"""
from utils.data_processor.processor import DataProcessor

__all__ = ['DataProcessor']