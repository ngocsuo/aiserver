#!/bin/bash
# Script cài đặt ETHUSDT Dashboard trên server

# Cài đặt các gói phụ thuộc
echo "Đang cài đặt các gói phụ thuộc..."
pip install -r requirements.txt

# Tạo các thư mục cần thiết
echo "Tạo các thư mục cần thiết..."
mkdir -p logs
mkdir -p data
mkdir -p saved_models
mkdir -p deployment/logs

# Đặt quyền thực thi cho các script
echo "Đặt quyền thực thi cho các script..."
chmod +x run_clean.py
chmod +x deployment/startup.sh

# Cấu hình systemd service (nếu người dùng có quyền root)
if [ "$(id -u)" = "0" ]; then
    echo "Phát hiện quyền root, đang cấu hình systemd service..."
    cat > /etc/systemd/system/ethusdt-dashboard.service << EOL
[Unit]
Description=ETHUSDT Dashboard Service
After=network.target

[Service]
ExecStart=/bin/bash -c "cd $(pwd) && python run_clean.py --mode service"
WorkingDirectory=$(pwd)
Restart=always
RestartSec=10
User=$(whoami)
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOL

    # Khởi động service
    systemctl daemon-reload
    systemctl enable ethusdt-dashboard.service
    systemctl start ethusdt-dashboard.service
    echo "Đã cấu hình và khởi động systemd service."
else
    echo "Không có quyền root, bỏ qua cấu hình systemd service."
    echo "Để chạy ứng dụng, sử dụng lệnh: python run_clean.py --mode service"
fi

echo "Cài đặt hoàn tất. Ứng dụng sẽ chạy tại http://localhost:5000"
