# ETHUSDT Dashboard - Hướng dẫn triển khai

## Cài đặt

1. Giải nén file zip
2. Di chuyển vào thư mục giải nén:
   ```
   cd ethusdt_dashboard
   ```
3. Chạy script cài đặt:
   ```
   ./install.sh
   ```

## Chạy thủ công

Nếu bạn không muốn cài đặt systemd service, bạn có thể chạy ứng dụng thủ công:

```
python run_clean.py --mode service
```

## Cấu hình

Bạn có thể chỉnh sửa file `config.py` để thay đổi cấu hình ứng dụng.

## Kiểm tra trạng thái

Kiểm tra trạng thái của service:

```
systemctl status ethusdt-dashboard.service
```

## Xem log

Xem log của ứng dụng:

```
tail -f logs/app.log
```

## Truy cập ứng dụng

Ứng dụng sẽ chạy tại http://localhost:5000
